import { useEffect, useState } from "react";
import { useNavigate } from 'react-router-dom';
import Handsontable from 'handsontable';
import 'handsontable/dist/handsontable.full.min.css';
import { registerAllModules } from 'handsontable/registry';
import { HotTable } from "@handsontable/react";
import { useCookies } from "react-cookie";

registerAllModules();

const Home = () => {
    const navigate = useNavigate();

    const [cookies, setCookie, removeCookie] = useCookies(['access_id']);

    const [funcionarios, setFuncionarios] = useState([])

    const [id, setId] = useState("")

    const handleLogout = () => {
        removeCookie('access_id')
        navigate('/login');
    };

    const handleDelete = () => {
        fetch('http://localhost:8080/funcionario/delete/' + id)
            .then(data => {
                console.log(data)
                window.location.reload(false);
            })
            .catch(error => console.error('Erro ao carregar funcionarios: ', error));
    };

    useEffect(() => {
        if(!cookies.access_id) {
            navigate('/login')
        }
        fetch('http://localhost:8080/funcionario/getAll')
            .then(response => response.json())
            .then(data => {
                console.log(data)
                let func = []
                for (const key of data) {
                    func.push([
                        key.id,
                        key.nome,
                        key.cargo,
                        `R$ ${key.salario}`
                    ])
                }
                setFuncionarios(func)
            })
            .catch(error => console.error('Erro ao carregar funcionarios: ', error));
    }, []);


    return (
        <div className="flex min-h-full flex-col justify-center px-6 py-12 lg:px-8">
            <div className="sm:mx-auto sm:w-full sm:max-w-xl">
                <img className="mx-auto h-10 w-auto" src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600" alt="Your Company" />
                <h1 className="text-center text-3xl font-bold leading-9 tracking-tight text-gray-900">R.O NA ESTRADA</h1>
                <h2 className="mt-5 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">Acesse o sistema</h2>
                <button
                    className="w-full p-3 mt-4 bg-indigo-600 text-white rounded shadow"
                    onClick={handleLogout}
                >
                    Logout
                </button>
                <button
                    className="w-full p-3 mt-4 bg-indigo-600 text-white rounded shadow"
                    onClick={() => navigate('/cadastroFuncionario')}
                >
                    Cadastrar funcionario
                </button>
                <HotTable
                    data={funcionarios}
                    rowHeaders={true}
                    colHeaders={['Matrícula', 'Nome', 'Cargo', 'Salário']}
                    filters={true}
                    height="auto"
                    licenseKey="non-commercial-and-evaluation"
                    style={{ margin: '32px 0' }}
                />
                <div className="relative mb-4 flex flex-wrap items-stretch">
                    <button
                        className="flex items-center border-indigo-600 whitespace-nowrap rounded-l border border-r-0 border-solid px-3 py-[0.25rem] text-center text-base font-normal leading-[1.6]"
                        onClick={() => navigate('/cadastroFuncionario/' + id)}
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L6.832 19.82a4.5 4.5 0 01-1.897 1.13l-2.685.8.8-2.685a4.5 4.5 0 011.13-1.897L16.863 4.487zm0 0L19.5 7.125" />
                        </svg>
                    </button>
                    <input
                        type="number"
                        className="relative m-0 block border-black w-[1px] min-w-0 flex-auto rounded-r border border-solid bg-clip-padding px-3 py-[0.25rem] text-base font-normal leading-[1.6]"
                        placeholder="Matrícula"
                        value={id}
                        onChange={e => setId(e.target.value)}
                    />
                </div>
                <div className="relative mb-4 flex flex-wrap items-stretch">
                    <input
                        type="number"
                        className="relative m-0 block border-black w-[1px] min-w-0 flex-auto rounded-r border border-solid  bg-clip-padding px-3 py-[0.25rem] text-base font-normal leading-[1.6]"
                        placeholder="Matrícula"
                        value={id}
                        onChange={e => setId(e.target.value)}
                    />
                    <button
                        className="flex items-center border-indigo-600 whitespace-nowrap rounded-r border border-l-0 border-solid px-3 py-[0.25rem] text-center text-base font-normal leading-[1.6]"
                        id="basic-addon1"
                        onClick={handleDelete}
                    >
                        Demitir funcionário
                    </button>
                </div>
                <img src="diagrama.svg" style={{width: '100%'}} />
            </div>
           
        </div>
    );
}

export default Home;