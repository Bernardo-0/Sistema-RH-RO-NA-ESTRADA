import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useCookies } from "react-cookie";

const CadastroFuncionario = () => {
    const [nome, setNome] = useState("");
    const [cargo, setCargo] = useState("");
    const [salario, setSalario] = useState("");
    const navigate = useNavigate();

    const { id } = useParams();

    const [cookies, setCookie] = useCookies(['access_id']);

    const handleSubmit = e => {
        e.preventDefault();
        if(!id) {
            fetch('http://localhost:8080/funcionario/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ nome: nome, salario: salario, cargo: cargo })
            })
                .then(data => {
                    if(data.status === 200) {
                        navigate('/');
                    }
                })
                .catch(error => console.error('Error:', error));
        } else {
            fetch('http://localhost:8080/funcionario/update/' + id, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ nome: nome, salario: salario, cargo: cargo })
            })
                .then(data => {
                    if(data.status === 200) {
                        navigate('/');
                    }
                })
                .catch(error => console.error('Error:', error));
        }
    };

    useEffect(() => {
        if(!cookies.access_id) {
            navigate('/login')
        }
        if(id) {
            fetch('http://localhost:8080/funcionario/get/' + id)
            .then(response => response.json())
            .then(data => {
                setNome(data.nome);
                setCargo(data.cargo);
                setSalario(data.salario);
            })
            .catch(error => console.error('Erro ao carregar funcionarios: ', error));
        }
    }, [])

    return (
        <div className="flex min-h-full flex-col justify-center px-6 py-12 lg:px-8">
            <div className="sm:mx-auto sm:w-full sm:max-w-sm">
                <img className="mx-auto h-10 w-auto" src="https://tailwindui.com/img/logos/mark.svg?color=indigo&shade=600" alt="Your Company" />
                <h1 className="text-center text-3xl font-bold leading-9 tracking-tight text-gray-900">R.O NA ESTRADA</h1>
                <h2 className="mt-5 text-center text-2xl font-bold leading-9 tracking-tight text-gray-900">Cadastro funcionário</h2>
            </div>

            <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <input name="id" type="text" value={id} disabled style={{display: 'none'}} />
                    <div>
                        <label className="block text-sm font-medium leading-6 text-gray-900">Nome</label>
                        <div className="mt-2">
                            <input name="nome" type="text" value={nome} onChange={e => setNome(e.target.value)} required className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium leading-6 text-gray-900">Cargo</label>
                        <div className="mt-2">
                            <input name="nome" type="text" value={cargo} onChange={e => setCargo(e.target.value)} required className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium leading-6 text-gray-900">Salário</label>
                        <div className="mt-2">
                            <input name="nome" type="number" step='0.01' value={salario} onChange={e => setSalario(e.target.value)} required className="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6" />
                        </div>
                    </div>

                    <div>
                        <button type="submit" className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Salvar</button>
                    </div>
                    <div>
                        <button onClick={() => navigate('/')} className="flex w-full justify-center rounded-md bg-indigo-600 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">Voltar</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default CadastroFuncionario;